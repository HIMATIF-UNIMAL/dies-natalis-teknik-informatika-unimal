          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              <div class="row justify-content-center">
                <div class=" col-lg-8 mb-3">
                  <div class="card h-100">
                    <img class="card-img-top" src="<?php echo base_url('theme/') ?>assets/img/backgrounds/dn19.jpg" alt="Card image cap">
                    <div class="card-body text-center">
                      <h5 class="card-title pt-5">Terima Kasih Telah Mendaftar</h5>
                      <p>data anda sedang kami proses <br><span class="text-success">E-ticket anda akan kami kirim via email</span></p>
                      <span>NOTE : Silahkan cek email secara berkala</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- / Content -->