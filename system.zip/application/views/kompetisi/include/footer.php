<?= $this->session->flashdata('msg'); ?>

            <!-- Footer -->
            <footer class="content-footer footer bg-footer-theme">
              <div class="container-xxl d-flex flex-wrap justify-content-center text-center py-2 flex-md-row flex-column">
                <div class="mb-2 mb-md-0">
                  
                  <script>
                    document.write(new Date().getFullYear());
                  </script>
                    © DN19. Powered by
                  <a href="https://himatif.unimal.ac.id" target="_blank" class="footer-link">HIMATIF UNIMAL</a>
                </div>
              </div>
            </footer>
            <!-- / Footer -->

            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->
        </div>
        <!-- / Layout page -->
      </div>
    </div>
    <!-- / Layout wrapper -->

    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="<?php echo base_url('theme/') ?>assets/vendor/libs/jquery/jquery.js"></script>
    <script src="<?php echo base_url('theme/') ?>assets/vendor/libs/popper/popper.js"></script>
    <script src="<?php echo base_url('theme/') ?>assets/vendor/js/bootstrap.js"></script>
    <script src="<?php echo base_url('theme/') ?>assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="<?php echo base_url('theme/') ?>assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->

    <!-- Main JS -->
    <script src="<?php echo base_url('theme/') ?>assets/js/main.js"></script>

  </body>
</html>
