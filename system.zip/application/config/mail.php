<?php
defined('BASEPATH') OR exit('No direct script access allowed');

      $config['mail'] = array(
        'protocol'  => 'smtp',
        'smtp_host' => 'ssl://smtp.googlemail.com',
        'smtp_user' => 'himatif@unimal.ac.id',
        'smtp_pass' => '!h1m@t1f2k22',
        'smtp_port' => 465,
        'mailtype'  => 'html',
        'charset'   => 'utf-8',
    );

    $config['addreas'] = 'himatif@unimal.ac.id';
?>